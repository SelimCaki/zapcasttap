export const translations = {
  az: {
    searchPlaceholder: "Ehtiyat hissəsi, marka və ya model axtarın...",
    categories: "Kategoriyalar",
    recentRequests: "Son Sorğular",
    createRequest: "Sorğu Yarat",
    loginGoogle: "Google ilə Daxil Ol",
    offers: "Təkliflər",
    profile: "Profil"
  },
  tr: {
    searchPlaceholder: "Yedek parça, marka veya model arayın...",
    categories: "Kategori̇ler",
    recentRequests: "Son Talepler",
    createRequest: "Talep Oluştur",
    loginGoogle: "Google ile Giriş Yap",
    offers: "Teklifler",
    profile: "Profil"
  },
  ru: {
    searchPlaceholder: "Поиск запчастей, марки или модели...",
    categories: "Категории",
    recentRequests: "Последние запросы",
    createRequest: "Создать запрос",
    loginGoogle: "Войти через Google",
    offers: "Предложения",
    profile: "Профиль"
  },
  en: {
    searchPlaceholder: "Search spare parts, make or model...",
    categories: "Categories",
    recentRequests: "Recent Requests",
    createRequest: "Create Request",
    loginGoogle: "Sign in with Google",
    offers: "Offers",
    profile: "Profile"
  }
}
