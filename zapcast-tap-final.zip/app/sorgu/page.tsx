import type { Metadata } from 'next'
import { CreateRequestForm } from '@/components/request/create-request-form'
import { ScreenHeader } from '@/components/screen-header'

export const metadata: Metadata = { title: 'Yeni Detal Sorğusu — ZapçastTap' }

export default function CreateRequestPage() {
  return (
    <main className="flex flex-1 flex-col">
      <ScreenHeader title="Yeni Detal Sorğusu" />
      <CreateRequestForm />
    </main>
  )
}
