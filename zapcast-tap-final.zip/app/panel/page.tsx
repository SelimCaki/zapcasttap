import type { Metadata } from 'next'
import { Store } from 'lucide-react'
import { BottomNav } from '@/components/bottom-nav'
import { SellerDashboard } from '@/components/dashboard/seller-dashboard'

export const metadata: Metadata = { title: 'Satıcı və Usta Paneli — ZapçastTap' }

export default function PanelPage() {
  return (
    <>
      <main className="flex flex-1 flex-col">
        <header className="flex items-center gap-3 bg-brand px-4 pb-4 pt-5 text-brand-foreground">
          <span className="flex size-11 items-center justify-center rounded-xl bg-primary">
            <Store className="size-5" aria-hidden="true" />
          </span>
          <div className="flex-1">
            <p className="text-xs text-slate-400">Babək Ölüxana #12</p>
            <h1 className="text-lg font-bold">Satıcı və Usta Paneli</h1>
          </div>
          <span className="rounded-full bg-green-500/15 px-2.5 py-1 text-[11px] font-bold text-green-300">
            Onlayn
          </span>
        </header>
        <SellerDashboard />
      </main>
      <BottomNav />
    </>
  )
}
